package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class BookmarksFragment extends Fragment implements OnItemClickListener {
    List<JSONObject> cards;
    private RecyclerView recyclerViewCard;
    private GridLayoutManager gridLayoutManager;
    private DividerItemDecoration itemDecoration;
    BookmarkAdapter bookmarkAdapter;
    List<String> articleList;
    TextView no_bookmark;
    View view;

    public BookmarksFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_bookmarks, container, false);
        recyclerViewCard = view.findViewById(R.id.recycler_view_bookmark);
        SharedPreferences pref = getContext().getSharedPreferences("bookmark", 0);
        Map<String,?> keys = pref.getAll();
        articleList = new ArrayList<>();
        no_bookmark = (TextView)view.findViewById(R.id.no_bookmark);
        for(Map.Entry<String,?> entry : keys.entrySet()){
            articleList.add(entry.getKey());
        }
        if(articleList.size() == 0) {
            Log.d("No Bookmark", "True");
            no_bookmark.setVisibility(View.VISIBLE);
        }
        else{
            no_bookmark.setVisibility(View.GONE);
        }
        setCardDisplay(articleList);
        return view;
    }

    private void setCardDisplay(List<String> articleList){
        bookmarkAdapter = new BookmarkAdapter(getContext(), articleList);
        gridLayoutManager = new GridLayoutManager(getContext(),2);
        itemDecoration = new DividerItemDecoration(recyclerViewCard.getContext(), gridLayoutManager.getOrientation());
        recyclerViewCard.addItemDecoration(itemDecoration);
        recyclerViewCard.setAdapter(bookmarkAdapter);
        recyclerViewCard.setLayoutManager(gridLayoutManager);
        bookmarkAdapter.setOnClickListener(this);
    }

    @Override
    public void onClick(View v, int position) {
        // The onClick implementation of the RecyclerView item click
        Intent i = new Intent(getContext(), ExpandedArticle.class);
        try {
            Log.d("Article id", String.valueOf(articleList));
            i.putExtra("articleId", articleList.get(position));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        startActivity(i);
    }

    @Override
    public void onLongClick(View view, final int position) {
        final Dialog dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog);
        ImageView twitter_icon = dialog.findViewById(R.id.twitter_icon);
        final View view2 = view;
        final ImageView bookmark_icon = dialog.findViewById(R.id.bookmark_icon);
        final SharedPreferences pref = getContext().getSharedPreferences("bookmark", 0);
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getAll().isEmpty() || !pref.contains(articleList.get(position))) {
            bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
        }
        else{
            bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
        }
        String articleId = articleList.get(position);
        final String article = pref.getString(articleId,"");
        Log.d("article object", article);
        JSONObject articleObj = null;
        try {
            articleObj = new JSONObject(article);
            Log.d("article object", String.valueOf(articleObj));
        }
        catch (Exception e){
            e.printStackTrace();
        }

        // Include dialog.xml file
        try {
            Log.d("article object", String.valueOf(articleObj));
            TextView dialog_text = (TextView) dialog.findViewById(R.id.dialog_title);
            dialog_text.setText(articleObj.getString("title"));
            ImageView dialog_image = (ImageView) dialog.findViewById(R.id.dialog_image);
            Picasso.get().load(articleObj.getString("image")).into(dialog_image);
            twitter_icon = (ImageView) dialog.findViewById(R.id.twitter_icon);
            Picasso.get().load("https://csci571.com/hw/hw9/images/android/bluetwitter.png").into(twitter_icon);
            dialog.show();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        final JSONObject finalArticleObj = articleObj;
        twitter_icon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Uri uri = null;
                try {
                    uri = Uri.parse("https://twitter.com/intent/tweet?text=Check out this Link: "+ finalArticleObj.getString("webUrl")+"&hashtags=CSCI571NewsSearch");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            }
        }
        );

        bookmark_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.remove(articleList.get(position));
                articleList.remove(position);
                RelativeLayout ll = (RelativeLayout) view2.getParent().getParent().getParent().getParent().getParent();
                TextView no_bookmark = (TextView)ll.findViewById(R.id.no_bookmark);
                if(articleList.size() == 0) {
                    Log.d("No Bookmark", "True");
                    no_bookmark.setVisibility(View.VISIBLE);
                }
                else{
                    no_bookmark.setVisibility(View.GONE);
                }
                bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
                try {
                    Toast.makeText(v.getContext(), finalArticleObj.getString("title") + " was removed from Bookmarks",
                            Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                bookmarkAdapter.notifyDataSetChanged();
                dialog.dismiss();
                editor.commit();
            }
        });
    }

    @Override
    public void onBookmarkCLick(View view, final int position) {
        final ImageView bookmark_icon = view.findViewById(R.id.bookmark_icon);
        final SharedPreferences pref = getContext().getSharedPreferences("bookmark", 0);
        final SharedPreferences.Editor editor = pref.edit();
        String articleId = articleList.get(position);
        final String article = pref.getString(articleId,"");
        JSONObject articleObj = null;
        try {
            articleObj = new JSONObject(article);

        }
        catch (Exception e){
            e.printStackTrace();
        }
        //final JSONObject finalArticleObj = articleObj;
        Log.d("Article object removed", String.valueOf(articleObj));
        editor.remove(articleList.get(position));
        articleList.remove(position);
        RelativeLayout ll = (RelativeLayout) view.getParent().getParent().getParent().getParent().getParent();
        TextView no_bookmark = (TextView)ll.findViewById(R.id.no_bookmark);
        if(articleList.size() == 0) {
            Log.d("No Bookmark", "True");
            no_bookmark.setVisibility(View.VISIBLE);
        }
        else{
            no_bookmark.setVisibility(View.GONE);
        }
        try {
            Toast.makeText(getContext(), articleObj.getString("title") + " was removed from Bookmarks",
                    Toast.LENGTH_LONG).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        bookmarkAdapter.notifyDataSetChanged();
        editor.commit();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(bookmarkAdapter!=null) {
            bookmarkAdapter.notifyDataSetChanged();
        }
        SharedPreferences pref = getContext().getSharedPreferences("bookmark", 0);
        Map<String,?> keys = pref.getAll();
        articleList = new ArrayList<>();
        no_bookmark = (TextView)view.findViewById(R.id.no_bookmark);
        for(Map.Entry<String,?> entry : keys.entrySet()){
            articleList.add(entry.getKey());
        }
        if(articleList.size() == 0) {
            Log.d("No Bookmark", "True");
            no_bookmark.setVisibility(View.VISIBLE);
        }
        else{
            no_bookmark.setVisibility(View.GONE);
        }
        setCardDisplay(articleList);
    }
}
