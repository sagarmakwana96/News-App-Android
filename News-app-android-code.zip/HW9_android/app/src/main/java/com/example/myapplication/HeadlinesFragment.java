package com.example.myapplication;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.myapplication.Sections.BusinessFragment;
import com.example.myapplication.Sections.PoliticsFragment;
import com.example.myapplication.Sections.ScienceFragment;
import com.example.myapplication.Sections.SportsFragment;
import com.example.myapplication.Sections.TechnologyFragment;
import com.example.myapplication.Sections.WorldFragment;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HeadlinesFragment extends Fragment {
    public HeadlinesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_headlines, container, false);
        final ViewPager viewPager = (ViewPager) view.findViewById(R.id.viewpager);

        TabLayout tabLayout = view.findViewById(R.id.tabs);
//        tabLayout.addTab(tabLayout.newTab().setText("WORLD"));
//        tabLayout.addTab(tabLayout.newTab().setText("BUSINESS"));
//        tabLayout.addTab(tabLayout.newTab().setText("POLITICS"));
//        tabLayout.addTab(tabLayout.newTab().setText("SPORTS"));
//        tabLayout.addTab(tabLayout.newTab().setText("TECHNOLOGY"));
//        tabLayout.addTab(tabLayout.newTab().setText("SCIENCE"));
//        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        final HeadlineAdapter adapter = new HeadlineAdapter(getChildFragmentManager());
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        adapter.addFragment(new WorldFragment(), "WORLD");
        adapter.addFragment(new BusinessFragment(), "BUSINESS");
        adapter.addFragment(new PoliticsFragment(), "POLITICS");
        adapter.addFragment(new SportsFragment(), "SPORTS");
        adapter.addFragment(new TechnologyFragment(), "TECHNOLOGY");
        adapter.addFragment(new ScienceFragment(), "SCIENCE");
        viewPager.setAdapter(adapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return view;
    }
}

class HeadlineAdapter extends FragmentPagerAdapter {
    private final List<Fragment> fragmentList = new ArrayList<>();
    private final List<String> fragmentSectionList = new ArrayList<>();

    public HeadlineAdapter(FragmentManager manager) {
        super(manager);
    }

    public void addFragment(Fragment fragment, String title) {
        fragmentList.add(fragment);
        fragmentSectionList.add(title);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                WorldFragment world = new WorldFragment();
                return world;
            case 1:
                BusinessFragment business = new BusinessFragment();
                return business;
            case 2:
                PoliticsFragment politics = new PoliticsFragment();
                return politics;
            case 3:
                SportsFragment sports = new SportsFragment();
                return sports;
            case 4:
                TechnologyFragment technology = new TechnologyFragment();
                return technology;
            case 5:
                ScienceFragment science = new ScienceFragment();
                return science;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return fragmentSectionList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return fragmentSectionList.get(position);
    }
}
