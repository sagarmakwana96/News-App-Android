package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.Manifest;
import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener,LocationListener {
    BottomNavigationView bottomNavigation;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 1;
    LocationManager locationManager;
    String cityName;
    String stateName;
    JSONArray query_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkLocationPermission();

        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    openFragment(new HomeFragment());
                    break;
                case R.id.navigation_headlines:
                    openFragment(new HeadlinesFragment());
                    break;
                case R.id.navigation_trending:
                    openFragment(new TrendingFragment());
                    break;
                case R.id.navigation_bookmarks:
                    openFragment(new BookmarksFragment());
                    break;
            }
            return true;
            }
        });
    }

    public void openFragment(Fragment fragment) {
        Bundle b = new Bundle();
        b.putString("city", cityName);
        Log.d("CITY NAME",cityName);
        b.putString("state", stateName);
        fragment.setArguments(b);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void checkLocationPermission() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        else{
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if(locationManager != null){
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,5, (LocationListener) this);
            }
        }
    }
    
    @Override
    public boolean onQueryTextSubmit(String query) {
        Intent i = new Intent(this, SearchActivity.class);
        i.putExtra("search_query", query);
        startActivity(i);
        return true;
    }
    
    @Override
    public boolean onQueryTextChange(String search_query) {
        Log.d("Inside","Query Text change");
        return true;
    }


    private void getSearchOptions(final androidx.appcompat.widget.SearchView.SearchAutoComplete autoSuggestions, String search_query){
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String jsonURL = "https://sagar-makwana.cognitiveservices.azure.com/bing/v7.0/suggestions?q="+search_query;
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {
                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        final String[] suggestions = new String[5];
                        try {
                            Log.d("Search Response", String.valueOf(response));
                            query_data = response.getJSONArray("suggestionGroups").getJSONObject(0).getJSONArray("searchSuggestions");
                            int data_length;
                            if(query_data.length() <= 5){
                                data_length = query_data.length();
                            }
                            else{
                                data_length = 5;
                            }
                            for(int i = 0; i< data_length; i++){
                                try {
                                    suggestions[i] = query_data.getJSONObject(i).getString("displayText");
                                }
                                catch (JSONException e){
                                    e.printStackTrace();
                                }
                            }
                            ArrayAdapter<String> queryAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_dropdown_item_1line, suggestions);
                            autoSuggestions.setAdapter(queryAdapter);
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", "Error");
                    }
                }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError{
                Map<String, String> key = new HashMap<>();
                key.put("Ocp-Apim-Subscription-Key", "c1cbe74aed344cf2a23b084336544bd7");
                return key;
            }
        };
        requestQueue.add(objectRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.action_bar_search_menu, menu);
        MenuItem searchMenu = menu.findItem(R.id.app_bar_menu_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        final androidx.appcompat.widget.SearchView searchView = (androidx.appcompat.widget.SearchView) searchMenu.getActionView();
        final androidx.appcompat.widget.SearchView.SearchAutoComplete autoSuggestions = searchView.findViewById(androidx.appcompat.R.id.search_src_text);

        autoSuggestions.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                String queryString = (String)parent.getItemAtPosition(position);
                autoSuggestions.setText(queryString);
                autoSuggestions.setSelection(autoSuggestions.getText().length());
//                Intent i = new Intent(view.getContext(), SearchActivity.class);
//                i.putExtra("search_query", queryString);
//                startActivity(i);
            }
        });
        searchView.setOnQueryTextListener(this);
        // Inflate the search menu action bar.
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconified(true);
        searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener(){
            @Override
            public boolean onQueryTextSubmit(String query) {
                Intent intent = new Intent(searchView.getContext(), SearchActivity.class);
                intent.putExtra("search_query", query);
                startActivity(intent);
                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
               if(newText.length() < 2)
                   return false;
               getSearchOptions(autoSuggestions, newText);
               return true;
            }
        });
        return true;
    }

    @Override
    public void onLocationChanged(Location location) {
        List<Address> addresses = null;
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        double longitude = location.getLongitude();
        double latitude = location.getLatitude();
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        cityName = addresses.get(0).getLocality();
        stateName = addresses.get(0).getAdminArea();
        Log.d("City",cityName);
        Log.d("State",stateName);
        openFragment(new HomeFragment());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case MY_PERMISSIONS_REQUEST_LOCATION:{
                if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,5,this);
                    }
                }
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}

