package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.DateFormatSymbols;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class BookmarkAdapter extends RecyclerView.Adapter<BookmarkAdapter.BookmarkHolder> {
    Context c;
    List<String> cards;
    OnItemClickListener itemClickListener;
    ZonedDateTime articleDate;
    ArticleCard card = new ArticleCard();

    public BookmarkAdapter(Context c, List<String> cards) {
        this.c = c;
        this.cards = cards;
    }

    @Override
    public BookmarkHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bookmark_card, null);
        BookmarkHolder viewHolder = new BookmarkHolder(view);
        Log.d("JSON DATA", String.valueOf(this.cards));
        return viewHolder;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(final BookmarkHolder holder, final int position) {
        final String id = cards.get(position);
        card.setArticleId(id);
        JSONObject articleObj = new JSONObject();
        final SharedPreferences pref = c.getSharedPreferences("bookmark", 0);
        final SharedPreferences.Editor editor = pref.edit();
        final String article = pref.getString(id,"");
        try {
            articleObj = new JSONObject(article);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            holder.bookmark_article_title.setText(articleObj.getString("title"));
            card.setArticleTitle(articleObj.getString("title"));
            Log.d("Article title :: ", articleObj.getString("title"));
            holder.bookmark_article_source.setText(articleObj.getString("section"));
            card.setArticleSource(articleObj.getString("section"));
            Picasso.get().load(articleObj.getString("image")).into(holder.bookmark_article_image);
            card.setArticleImage(articleObj.getString("image"));
            articleDate = ZonedDateTime.parse(articleObj.getString("date")).withZoneSameLocal(ZoneId.of("GMT"));
            card.setArticleDate(articleObj.getString("date"));
            articleDate = articleDate.withZoneSameInstant(ZoneId.of("America/Los_Angeles"));
            LocalDateTime dateTime = articleDate.toLocalDateTime();
            DateFormatSymbols dateFormatSymbols = new DateFormatSymbols();
            String[] months = dateFormatSymbols.getMonths();
            String date = dateTime.getDayOfMonth() + " " + months[dateTime.getMonthValue() - 1];
            holder.bookmark_article_time.setText(date);
            Log.d("DATE",date);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JSONObject finalArticleObj = articleObj;
//        holder.bookmark_icon.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                editor.remove(id);
//                cards.remove(position);
//                try {
//                    Toast.makeText(v.getContext(), finalArticleObj.getString("title") + " was removed from Bookmarks",
//                            Toast.LENGTH_LONG).show();
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//                notifyDataSetChanged();
//                editor.commit();
//            }
//        });
    }

    public void setOnClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public int getItemCount() {
        return cards.size();
    }

    class BookmarkHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
        ImageView bookmark_article_image, bookmark_icon;
        TextView bookmark_article_title, bookmark_article_source, no_article, bookmark_article_time, no_bookmark;
        CardView cv;

        public BookmarkHolder(@NonNull View view) {
            super(view);
            this.bookmark_article_image = view.findViewById(R.id.bookmark_article_image);
            this.bookmark_article_title = view.findViewById(R.id.bookmark_article_title);
            this.bookmark_article_source = view.findViewById(R.id.bookmark_article_source);
            this.bookmark_article_time = view.findViewById(R.id.bookmark_article_time);
            this.no_bookmark = view.findViewById(R.id.no_bookmark);
            this.bookmark_icon = view.findViewById(R.id.bookmark_icon);
            this.cv = view.findViewById(R.id.bookmark_card);
            final SharedPreferences pref = c.getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
            final SharedPreferences.Editor editor = pref.edit();
            view.setOnClickListener(this);
            view.setOnLongClickListener(this);
            this.bookmark_icon.setOnClickListener(this);
        }



        @Override
        public void onClick(View v) {
            if(v.getId() == R.id.bookmark_icon)
            {
                itemClickListener.onBookmarkCLick(v, getAdapterPosition());
                return;
            }
            itemClickListener.onClick(v, getAdapterPosition());
        }

        @Override
        public boolean onLongClick(View v) {
            itemClickListener.onLongClick(v, getAdapterPosition());
            return true;
        }
    }
}
