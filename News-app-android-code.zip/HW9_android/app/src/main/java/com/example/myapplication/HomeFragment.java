package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */

public class HomeFragment extends Fragment implements OnItemClickListener {
    private String cityName, stateName, weatherType;
    private int curr_temperature;
    private String TAG = "JSON data";
    private boolean dataStatus, articleStatus;
    private RecyclerView recyclerView;
    private MyAdapter articleAdapter;
    private RecyclerView.LayoutManager layoutManager;
    Handler articleHandler;
    ArrayList<ArticleCard> cards;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ProgressBar spinner;
    private TextView progressbar_text;
    private RecyclerView recyclerViewCard;
    private LinearLayoutManager linearLayoutManager;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_home, container, false);
        dataStatus = false;
        articleStatus = false;
        Bundle bundle = getArguments();
        cityName = Objects.requireNonNull(bundle.getString("city"));
        stateName = Objects.requireNonNull(bundle.getString("state"));
        Log.d("cityname", cityName);
        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        articleHandler = new Handler();
        spinner = (ProgressBar)view.findViewById(R.id.progressBar);
        progressbar_text = (TextView)view.findViewById(R.id.progressbar_text);
        recyclerViewCard = (RecyclerView)view.findViewById(R.id.recycler_view);
        recyclerViewCard.setVisibility(View.GONE);
        spinner.setVisibility(View.VISIBLE);
        progressbar_text.setVisibility(View.VISIBLE);
        fetchCurrentWeather();
        final Runnable runnableCode = new Runnable() {
            @Override
            public void run() {
                // Do something here on the main thread
                if(dataStatus){
                    displayWeatherCard(view);
                }
                else {
                    articleHandler.postDelayed(this, 200);
                }
            }
        };
        articleHandler.post(runnableCode);

        getNewsCards(view);
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if(articleStatus){
                    recyclerViewCard.setVisibility(View.VISIBLE);
                    spinner.setVisibility(View.GONE);
                    progressbar_text.setVisibility(View.GONE);
                    setCardDisplay();
                }
                else {
                    articleHandler.postDelayed(this, 200);
                }
            }
        };
        articleHandler.post(runnable);
        cards = new ArrayList<>();

        mSwipeRefreshLayout = view.findViewById(R.id.swipe_refresh_items);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                dataStatus = false;
                articleStatus = false;
                fetchCurrentWeather();
                final Runnable runnableCode = new Runnable() {
                    @Override
                    public void run() {
                        // Do something here on the main thread
                        if(dataStatus){
                            displayWeatherCard(view);
                        }
                        else {
                            articleHandler.postDelayed(this, 200);
                        }
                    }
                };
                articleHandler.post(runnableCode);

                getNewsCards(view);
                final Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        if(articleStatus){
                            mSwipeRefreshLayout.setRefreshing(false);
                            Log.d("HELLLLLLLLOOOOOOOOO","ANDROIDDDDDDD");
                            setCardDisplay();
                        }
                        else {
                            articleHandler.postDelayed(this, 200);
                        }
                    }
                };
                articleHandler.post(runnable);
            }
        });
        return view;
    }

    private void setCardDisplay() {
        articleAdapter = new MyAdapter(getContext(), cards);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setAdapter(articleAdapter);
        recyclerView.setLayoutManager(layoutManager);
        articleAdapter.setOnClickListener(this);
        articleAdapter.notifyDataSetChanged();
    }

    private void getNewsCards(View view) {
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        recyclerViewCard = view.findViewById(R.id.recycler_view);
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerViewCard.setLayoutManager(linearLayoutManager);
        String jsonURL = "http://androidnewsapp.us-east-1.elasticbeanstalk.com/home";
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject responseObj = response.getJSONObject("data").getJSONObject("response");
                            JSONArray results = responseObj.getJSONArray("results");
                            for(int i = 0; i < results.length(); i ++){
                                ArticleCard card = new ArticleCard();
                                JSONObject resultsObj = results.getJSONObject(i);
                                card.setArticleTitle(resultsObj.getString("webTitle"));
                                card.setArticleSource(resultsObj.getString("sectionName"));
                                card.setArticleUrl(resultsObj.getString("webUrl"));
                                card.setArticleId(resultsObj.getString("id"));
                                card.setArticleDate(resultsObj.getString("webPublicationDate"));
                                JSONObject fieldsObj = resultsObj.getJSONObject("fields");
                                try {
                                    card.setArticleImage(fieldsObj.getString("thumbnail"));
                                }
                                catch(Exception e){
                                    card.setArticleImage("https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png");
                                }
                                cards.add(card);

                            }
                            articleStatus = true;
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", "Error");
                    }
                }
        );
        requestQueue.add(objectRequest);

    }

    @SuppressLint("SetTextI18n")
    private void displayWeatherCard(View view){
        String imageURL;
        TextView city_name = view.findViewById(R.id.city_name);
        city_name.setText(cityName);
        TextView state_name = view.findViewById(R.id.state_name);
        state_name.setText(stateName);
        TextView temperature = view.findViewById(R.id.temperature);
        temperature.setText(curr_temperature + " \u2103");
        TextView weather_type = view.findViewById(R.id.weather_type);
        weather_type.setText(weatherType);

        switch (weatherType) {
            case "Clouds":
                imageURL = "https://csci571.com/hw/hw9/images/android/cloudy_weather.jpg";
                break;
            case "Clear":
                imageURL = "https://csci571.com/hw/hw9/images/android/clear_weather.jpg";
                break;
            case "Snow":
                imageURL = "https://csci571.com/hw/hw9/images/android/snowy_weather.jpeg";
                break;
            case "Rain":
            case "Drizzle":
                imageURL = "https://csci571.com/hw/hw9/images/android/rainy_weather.jpg";
                break;
            case "Thunderstorm":
                imageURL = "https://csci571.com/hw/hw9/images/android/thunder_weather.jpg";
                break;
            default:
                imageURL = "https://csci571.com/hw/hw9/images/android/sunny_weather.jpg";
                break;
        }
        ImageView weather_image = view.findViewById(R.id.weather_image);
        Picasso.get().load(imageURL).into(weather_image);
    }

    private void fetchCurrentWeather(){
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        String jsonURL = "https://api.openweathermap.org/data/2.5/weather?q="+cityName+"&units=metric&appid=5b49a3f5239f59ed06184f2e02595529";
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject arr = (JSONObject) response.getJSONArray("weather").get(0);
                            weatherType = arr.getString("main");
                            JSONObject obj = response.getJSONObject("main");
                            curr_temperature = obj.getInt("temp");
                            dataStatus = true;
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", "Error");
                    }
                }
        );
        requestQueue.add(objectRequest);
    }


    @Override
    public void onClick(View v, int position) {
        // The onClick implementation of the RecyclerView item click
        Intent i = new Intent(getContext(), ExpandedArticle.class);
        i.putExtra("articleId", cards.get(position).getArticleId());
        startActivity(i);
    }

    @Override
    public void onLongClick(View v, final int position) {
        final Dialog dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog);

        TextView dialog_text = dialog.findViewById(R.id.dialog_title);
        dialog_text.setText(cards.get(position).getArticleTitle());
        ImageView dialog_image = dialog.findViewById(R.id.dialog_image);
        Picasso.get().load(cards.get(position).getArticleImage()).into(dialog_image);
        ImageView twitter_icon = dialog.findViewById(R.id.twitter_icon);
        Picasso.get().load("https://csci571.com/hw/hw9/images/android/bluetwitter.png").into(twitter_icon);

        final ImageView bookmark_icon = dialog.findViewById(R.id.bookmark_icon);

        final SharedPreferences pref = getContext().getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getAll().isEmpty() || !pref.contains(cards.get(position).getArticleId())) {
            bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
        }
        else{
            bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
        }

        twitter_icon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://twitter.com/intent/tweet?text=Check out this Link: "+cards.get(position).getArticleUrl()+ "&hashtags=CSCI571NewsSearch");
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            }
        }
        );

        bookmark_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pref.contains(cards.get(position).getArticleId())){
                    editor.remove(cards.get(position).getArticleId());
                    bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
                    Toast.makeText(v.getContext(), cards.get(position).getArticleTitle() + " was removed from Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    JSONObject article = new JSONObject();
                    try {
                        article.put("id", cards.get(position).getArticleId());
                        article.put("title", cards.get(position).getArticleTitle());
                        article.put("image", cards.get(position).getArticleImage());
                        article.put("section", cards.get(position).getArticleSource());
                        article.put("date",cards.get(position).getArticleDate());
                        Log.d("JSON DATA", String.valueOf(article));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    editor.putString(cards.get(position).getArticleId(), article.toString());
                    bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
                    Toast.makeText(v.getContext(), cards.get(position).getArticleTitle()+" was added to Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                articleAdapter.notifyDataSetChanged();
                editor.commit();

            }
        });
        dialog.show();
    }

    @Override
    public void onBookmarkCLick(View view, int position) {

    }

    @Override
    public void onResume() {
        super.onResume();
        if(articleAdapter!=null) {
            articleAdapter.notifyDataSetChanged();
        }
    }
}
