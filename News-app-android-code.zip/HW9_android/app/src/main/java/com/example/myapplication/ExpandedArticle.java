package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormatSymbols;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ExpandedArticle extends AppCompatActivity {
    String imageURL;
    String articleTitle, articleLink;
    String articleSection;
    ZonedDateTime articleDate;
    String articleDescription = "";
    boolean dataStatus;
    Handler mHandler;
    JSONObject results;
    private String TAG = "EXPANDED JSON";
    private ProgressBar spinner;
    private MyAdapter articleAdapter;
    private BookmarkAdapter bookmarkAdapter;
    private CardView cardView;
    private RelativeLayout relativeLayout;
    ImageView bookmark_icon, twitter_icon, back_icon;
    String articleId;
    private TextView progressbar_text;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expanded_article);



        Intent intent = getIntent();
        articleId = intent.getStringExtra("articleId");
//        String articleId = "technology/2020/apr/15/amazon-lockdown-bonanza-jeff-bezos-fortune-109bn-coronavirus"
        dataStatus = false;
        fetchArticle(articleId);
        mHandler = new Handler();
        spinner = (ProgressBar)findViewById(R.id.progressBar);
        progressbar_text = (TextView)findViewById(R.id.progressbar_text);
        cardView = (CardView)findViewById(R.id.expanded_article_card);
        relativeLayout = (RelativeLayout)findViewById(R.id.top_bar);
        bookmark_icon = (ImageView)findViewById(R.id.bookmark_icon);
        twitter_icon = (ImageView)findViewById(R.id.twitter_icon);
        back_icon = (ImageView)findViewById(R.id.back_icon);
        spinner.setVisibility(View.VISIBLE);
        progressbar_text.setVisibility(View.VISIBLE);
        cardView.setVisibility(View.GONE);
        relativeLayout.setVisibility(View.GONE);


        final Runnable runnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                // Do something here on the main thread
                if(dataStatus){
                    spinner.setVisibility(View.GONE);
                    progressbar_text.setVisibility(View.GONE);
                    cardView.setVisibility(View.VISIBLE);
                    relativeLayout.setVisibility(View.VISIBLE);
                    displayArticle();
                }
                else {
                    // Repeat this the same runnable code block again another 2 seconds
                    // 'this' is referencing the Runnable object
                    mHandler.postDelayed(this, 200);
                }
            }
        };

        final SharedPreferences pref = getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getAll().isEmpty() || !pref.contains(articleId)) {
            this.bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
        }
        else{
            this.bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
        }

        this.twitter_icon.setOnClickListener(new View.OnClickListener(){
             @Override
             public void onClick(View v) {
                 Uri uri = Uri.parse("https://twitter.com/intent/tweet?text=Check out this Link: "+articleLink+"&hashtags=CSCI571NewsSearch");
                 Intent i = new Intent(Intent.ACTION_VIEW, uri);
                 startActivity(i);
             }
         }
         );

        this.back_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        this.bookmark_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pref.contains(articleId)){
                    editor.remove(articleId);
                    bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
                    Toast.makeText(v.getContext(), articleTitle + " was removed from Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    JSONObject article = new JSONObject();
                    try {
                        article.put("id", articleId);
                        article.put("title", articleTitle);
                        article.put("image", imageURL);
                        article.put("section", articleSection);
                        article.put("date",articleDate);
                        Log.d("JSON DATA", String.valueOf(article));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    editor.putString(articleId, article.toString());
                    bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
                    Toast.makeText(v.getContext(), articleTitle+" was added to Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                editor.commit();
            }
        });


        mHandler.post(runnable);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void displayArticle(){
        ImageView expanded_article_image = findViewById(R.id.expanded_article_image);
        ImageView twitter_icon = findViewById(R.id.twitter_icon);
        TextView expanded_article_title = findViewById(R.id.expanded_article_title);
        TextView expanded_article_date = findViewById(R.id.expanded_article_date);
        TextView expanded_article_section = findViewById(R.id.expanded_article_section);
        TextView top_article_title = findViewById(R.id.top_article_title);
        TextView description = findViewById(R.id.description);
        TextView article_link = findViewById(R.id.article_link);
        ImageView back_icon = findViewById(R.id.back_icon);
        DateFormatSymbols dateFormatSymbols = new DateFormatSymbols();
        String[] months = dateFormatSymbols.getMonths();
        String date;
        try {
            try {
                imageURL = results.getJSONObject("blocks").getJSONObject("main").getJSONArray("elements").getJSONObject(0).getJSONArray("assets").getJSONObject(0).getString("file");
            } catch (Exception ex) {
                imageURL = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
            }
            Picasso.get().load(imageURL).into(expanded_article_image);
            Picasso.get().load("https://csci571.com/hw/hw9/images/android/bluetwitter.png").into(twitter_icon);
            articleTitle = results.getString("webTitle");
            expanded_article_title.setText(articleTitle);
            top_article_title.setText(articleTitle);
            articleSection = results.getString("sectionName");
            articleLink = results.getString("webUrl");
            expanded_article_section.setText(articleSection);
            articleDate = ZonedDateTime.parse(results.getString("webPublicationDate")).withZoneSameLocal(ZoneId.of("GMT"));
            articleDate = articleDate.withZoneSameInstant(ZoneId.of("America/Los_Angeles"));
            LocalDateTime dateTime = articleDate.toLocalDateTime();
            date = dateTime.getDayOfMonth() + " " + months[dateTime.getMonthValue() - 1] + " " + dateTime.getYear();
            expanded_article_date.setText(date);
//            Log.d(TAG,articleTitle);
            JSONArray desc = results.getJSONObject("blocks").getJSONArray("body");
            for(int i = 0; i < desc.length(); i ++) {
                articleDescription += desc.getJSONObject(i).getString("bodyHtml");
            }
            Log.d(TAG,articleDescription);
            Spanned sp = Html.fromHtml(articleDescription);
            description.setText(sp);
            Spanned full_link = Html.fromHtml("<a href ="+articleLink+"> View Full Article</a>");
            article_link.setMovementMethod(LinkMovementMethod.getInstance());
            article_link.setText(full_link);
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
    }

    private void fetchArticle(String articleId){

        RequestQueue requestQueue = Volley.newRequestQueue(getBaseContext());
//        https://content.guardianapis.com/technology/2020/apr/15/amazon-lockdown-bonanza-jeff-bezos-fortune-109bn-coronavirus?api-key=d53c9e4d-5261-4e55-ada8-2dcd03e8af91&show-blocks=all
        String jsonURL = "http://androidnewsapp.us-east-1.elasticbeanstalk.com/fullArticle/"+articleId.replaceAll("/","_");
        JsonObjectRequest obreq = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            System.out.println("JSON response" + response);
                            JSONObject responseObj = response.getJSONObject("data").getJSONObject("response");
                            Log.d(TAG, String.valueOf(responseObj));
                            results = responseObj.getJSONObject("content");
                            dataStatus = true;
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", "Error");
                    }
                }
        );
        requestQueue.add(obreq);
    }
}
