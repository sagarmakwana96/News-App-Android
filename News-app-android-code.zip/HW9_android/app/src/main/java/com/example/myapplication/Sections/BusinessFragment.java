package com.example.myapplication.Sections;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.ArticleCard;
import com.example.myapplication.ExpandedArticle;
import com.example.myapplication.MyAdapter;
import com.example.myapplication.OnItemClickListener;
import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class BusinessFragment extends Fragment implements OnItemClickListener {
    boolean articleStatus;
    private MyAdapter articleAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView recyclerView;
    Handler mHandler;
    ArrayList<ArticleCard> cards;
    private String TAG = "JSON sagar data";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ProgressBar spinner;
    private TextView progressbar_text;
    private RecyclerView recyclerViewCard;
    private LinearLayoutManager linearLayoutManager;
    DividerItemDecoration itemDecoration;

    public BusinessFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_business, container, false);
        mHandler = new Handler();
        articleStatus = false;
        spinner = (ProgressBar)view.findViewById(R.id.progressBar);
        recyclerViewCard = (RecyclerView)view.findViewById(R.id.recycler_view);
        recyclerViewCard.setVisibility(View.GONE);
        spinner.setVisibility(View.VISIBLE);
        progressbar_text = (TextView)view.findViewById(R.id.progressbar_text);
        progressbar_text.setVisibility(View.VISIBLE);
        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        cards = new ArrayList<>();
        getNewsCards(view);
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // Do something here on the main thread
                if(articleStatus){
                    recyclerViewCard.setVisibility(View.VISIBLE);
                    spinner.setVisibility(View.GONE);
                    progressbar_text.setVisibility(View.GONE);
                    setCardDisplay();
                }
                else {
                    // Repeat this the same runnable code block again another 2 seconds
                    // 'this' is referencing the Runnable object
                    mHandler.postDelayed(this, 200);
                }
            }
        };
        mHandler.post(runnable);

        mSwipeRefreshLayout = view.findViewById(R.id.swipe_refresh_items);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                articleStatus = false;
                getNewsCards(view);
                final Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        // Do something here on the main thread
                        if(articleStatus){
                            mSwipeRefreshLayout.setRefreshing(false);
                            Log.d("HELLLLLLLLOOOOOOOOO","ANDROIDDDDDDD");
                            setCardDisplay();
                        }
                        else {
                            // Repeat this the same runnable code block again another 2 seconds
                            // 'this' is referencing the Runnable object
                            mHandler.postDelayed(this, 200);
                        }
                    }
                };
                mHandler.post(runnable);
            }
        });
        return view;
    }

    private void setCardDisplay() {
        articleAdapter = new MyAdapter(getContext(), cards);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setAdapter(articleAdapter);
        recyclerView.setLayoutManager(layoutManager);
        articleAdapter.setOnClickListener(this);
        articleAdapter.notifyDataSetChanged();
    }

    private void getNewsCards(View view) {
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        recyclerViewCard = view.findViewById(R.id.recycler_view);
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerViewCard.setLayoutManager(linearLayoutManager);
        itemDecoration = new DividerItemDecoration(getContext(), linearLayoutManager.getOrientation());
        recyclerViewCard.addItemDecoration(itemDecoration);

        String jsonURL = "http://androidnewsapp.us-east-1.elasticbeanstalk.com/section/business";

        JsonObjectRequest obreq = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            System.out.println("JSON response" + response);
                            JSONObject responseObj = response.getJSONObject("data").getJSONObject("response");
                            JSONArray results = responseObj.getJSONArray("results");
                            Log.d(TAG, String.valueOf(results.length()));
                            for(int i = 0; i < results.length(); i ++){
                                ArticleCard card = new ArticleCard();
                                JSONObject resultsObj = results.getJSONObject(i);
                                card.setArticleTitle(resultsObj.getString("webTitle"));
                                card.setArticleSource(resultsObj.getString("sectionName"));
                                card.setArticleId(resultsObj.getString("id"));
                                card.setArticleUrl(resultsObj.getString("webUrl"));
                                card.setArticleDate(resultsObj.getString("webPublicationDate"));
                                Log.d(TAG, "Retrieved item " + i);
                                try {
                                    card.setArticleImage(resultsObj.getJSONObject("blocks").getJSONObject("main").getJSONArray("elements").getJSONObject(0).getJSONArray("assets").getJSONObject(0).getString("file"));
                                }
                                catch(Exception e){
                                    card.setArticleImage("https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png");
                                }
                                cards.add(card);
                                Log.d(TAG, String.valueOf(resultsObj));
                            }
                            articleStatus = true;
                        }
                        // Try and catch are included to handle any errors due to JSON
                        catch (JSONException e) {
                            // If an error occurs, this prints the error to the log
                            e.printStackTrace();
                            Log.d(TAG, e.toString());
                        }

                    }
                },
                // The final parameter overrides the method onErrorResponse() and passes VolleyError
                //as a parameter
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley: ", error.toString());
                    }
                }

        );
        // Adds the JSON object request "obreq" to the request queue
        requestQueue.add(obreq);
    }

    @Override
    public void onClick(View v, int position) {
        // The onClick implementation of the RecyclerView item click
        Intent i = new Intent(getContext(), ExpandedArticle.class);
        i.putExtra("articleId", cards.get(position).getArticleId());
        startActivity(i);
    }

    @Override
    public void onLongClick(View v, final int position) {
        // The onClick implementation of the RecyclerView item click
        final Dialog dialog = new Dialog(getContext());
        // Include dialog.xml file
        dialog.setContentView(R.layout.dialog);
        TextView dialog_text = (TextView) dialog.findViewById(R.id.dialog_title);
        dialog_text.setText(cards.get(position).getArticleTitle());
        ImageView dialog_image = (ImageView) dialog.findViewById(R.id.dialog_image);
        Picasso.get().load(cards.get(position).getArticleImage()).into(dialog_image);
        ImageView twitter_icon = (ImageView) dialog.findViewById(R.id.twitter_icon);
        Picasso.get().load("https://csci571.com/hw/hw9/images/android/bluetwitter.png").into(twitter_icon);
        final ImageView bookmark_icon = dialog.findViewById(R.id.bookmark_icon);

        final SharedPreferences pref = getContext().getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getAll().isEmpty() || !pref.contains(cards.get(position).getArticleId())) {
            bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
        }
        else{
            bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
        }

        twitter_icon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://twitter.com/intent/tweet?text=Check out this Link: "+cards.get(position).getArticleUrl()+ "&hashtags=CSCI571NewsSearch");
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            }
        }
        );

        bookmark_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pref.contains(cards.get(position).getArticleId())){
                    editor.remove(cards.get(position).getArticleId());
                    bookmark_icon.setBackgroundResource(R.drawable.ic_article_bookmark);
                    Toast.makeText(v.getContext(), cards.get(position).getArticleTitle() + " was removed from Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    JSONObject article = new JSONObject();
                    try {
                        article.put("id", cards.get(position).getArticleId());
                        article.put("title", cards.get(position).getArticleTitle());
                        article.put("image", cards.get(position).getArticleImage());
                        article.put("section", cards.get(position).getArticleSource());
                        article.put("date",cards.get(position).getArticleDate());
                        Log.d("JSON DATA", String.valueOf(article));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    editor.putString(cards.get(position).getArticleId(), article.toString());
                    bookmark_icon.setBackgroundResource(R.drawable.ic_bookmark_filled);
                    Toast.makeText(v.getContext(), cards.get(position).getArticleTitle()+" was added to Bookmarks",
                            Toast.LENGTH_LONG).show();
                }
                articleAdapter.notifyDataSetChanged();
                editor.commit();
            }
        });
        dialog.show();
    }

    @Override
    public void onBookmarkCLick(View view, int position) {

    }

    @Override
    public void onResume() {
        super.onResume();
        if(articleAdapter!=null) {
            articleAdapter.notifyDataSetChanged();
        }
    }
}
