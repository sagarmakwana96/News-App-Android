package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {
    Context c;
    ArrayList<ArticleCard> cards;
    OnItemClickListener itemClickListener;
    JSONObject article = new JSONObject();

    public MyAdapter(Context c, ArrayList<ArticleCard> cards) {
        this.c = c;
        this.cards = cards;
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.article_card, null);
        MyHolder viewHolder = new MyHolder(view);
        return viewHolder;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        ZoneId zoneId = ZoneId.of("GMT");
        ZonedDateTime articleDatePdt = ZonedDateTime.parse(cards.get(position).getArticleDate()).withZoneSameLocal(ZoneId.of("GMT"));
        ZonedDateTime current = ZonedDateTime.now(ZoneId.of("GMT"));
        long timeDiff = ChronoUnit.SECONDS.between(articleDatePdt, current);
        if(timeDiff/86400 > 0){
            holder.article_time.setText(timeDiff/86400 +"d ago");
        }
        else if(timeDiff/3600 > 0){
            holder.article_time.setText(timeDiff/3600 +"h ago");
        }
        else if(timeDiff/60 > 0){
            holder.article_time.setText(timeDiff/60 +"m ago");
        }
        else{
            holder.article_time.setText(timeDiff + "s ago");
        }

        holder.article_title.setText(cards.get(position).getArticleTitle());
        holder.article_source.setText(cards.get(position).getArticleSource());
        Picasso.get().load(cards.get(position).getArticleImage()).into(holder.article_image);
        final SharedPreferences pref = c.getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getAll().isEmpty() || !pref.contains(cards.get(position).getArticleId())) {
            holder.bookmark.setBackgroundResource(R.drawable.ic_article_bookmark);
        }
        else{
            holder.bookmark.setBackgroundResource(R.drawable.ic_bookmark_filled);
        }
    }

    public void setOnClickListener(OnItemClickListener itemClickListener){
        this.itemClickListener = itemClickListener;
    }


    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return cards.size();
    }

    class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
        ImageView article_image, bookmark;
        TextView article_title, article_source, article_time, search_keyword;;

        public MyHolder(@NonNull final View view){
            super(view);
            this.article_image = view.findViewById(R.id.article_image);
            this.article_title = view.findViewById(R.id.article_title);
            this.article_source = view.findViewById(R.id.article_source);
            this.bookmark = view.findViewById(R.id.bookmark_icon);
            this.article_time = view.findViewById(R.id.article_time);
            this.search_keyword = view.findViewById(R.id.search_keyword);
            final SharedPreferences pref = c.getApplicationContext().getSharedPreferences("bookmark", 0); // 0 - for private mode
            final SharedPreferences.Editor editor = pref.edit();

            this.bookmark.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ArticleCard articleCard = cards.get(getAdapterPosition());
                    if(pref.contains(articleCard.getArticleId())){
                        editor.remove(articleCard.getArticleId());
                        bookmark.setBackgroundResource(R.drawable.ic_article_bookmark);
                        Toast.makeText(view.getContext(), articleCard.getArticleTitle()+" was removed from Bookmarks",
                                Toast.LENGTH_LONG).show();
                    }
                    else {

                        try {
                            article.put("id", articleCard.getArticleId());
                            article.put("title", articleCard.getArticleTitle());
                            article.put("image", articleCard.getArticleImage());
                            article.put("section", articleCard.getArticleSource());
                            article.put("date",articleCard.getArticleDate());
                            article.put("webUrl", articleCard.getArticleUrl());
                            Log.d("JSON DATA", String.valueOf(article));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        editor.putString(articleCard.getArticleId(), article.toString());
                        bookmark.setBackgroundResource(R.drawable.ic_bookmark_filled);
                        Toast.makeText(view.getContext(), articleCard.getArticleTitle()+" was added to Bookmarks",
                                Toast.LENGTH_LONG).show();
                    }
                    editor.commit();

                }
            });
            view.setOnClickListener(this);
            view.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View v) {
            itemClickListener.onClick(v, getAdapterPosition());
        }
        @Override
        public boolean onLongClick(View v) {
            itemClickListener.onLongClick(v, getAdapterPosition());
            return true;
        }
    }
}