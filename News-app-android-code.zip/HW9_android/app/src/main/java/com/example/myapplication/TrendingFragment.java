package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.Key;
import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class TrendingFragment extends Fragment {
    private boolean dataStatus;
    private String keyword = "coronavirus";
    private JSONArray trendingWordData;
    private EditText editText;
    public TrendingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_trending, container, false);
        dataStatus = false;
        editText = view.findViewById(R.id.edit_text);
        fetchTrendingKeyword(keyword);
        final Handler dataHandler = new Handler();
        final Runnable runnableCode = new Runnable() {
            @Override
            public void run() {
                // Do something here on the main thread
                if(dataStatus){
                    generateMPChart(view);
                }
                else {
                    dataHandler.postDelayed(this, 200);
                }
            }
        };
        dataHandler.post(runnableCode);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEND||event.getAction() == KeyEvent.ACTION_DOWN ) {
                    dataStatus = false;
                    keyword = editText.getText().toString();
                    fetchTrendingKeyword(keyword);
                    final Handler dataHandler = new Handler();
                    final Runnable runnableCode = new Runnable() {
                        @Override
                        public void run() {
                            // Do something here on the main thread
                            if(dataStatus){
                                generateMPChart(view);
                            }
                            else {
                                dataHandler.postDelayed(this, 200);
                            }
                        }
                    };
                    dataHandler.post(runnableCode);
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    private void generateMPChart(View view){
        LineChart line_Chart = view.findViewById(R.id.line_chart);
        Legend legend = line_Chart.getLegend();
        legend.setTextColor(Color.parseColor("#000000"));
        legend.setTextSize(15);
        List<Entry> entries = new ArrayList<Entry>();
        for(int i = 0; i < trendingWordData.length(); i++){
            try {
                int dataCount = trendingWordData.getJSONObject(i).getJSONArray("value").getInt(0);
                entries.add(new Entry(i,dataCount));
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        LineDataSet dataSet = new LineDataSet(entries, "Trending chart for "+keyword);

        dataSet.setColor(Color.parseColor("#6200ee"));
        dataSet.setCircleColor(Color.parseColor("#6200ee"));
        dataSet.setValueTextColor(Color.parseColor("#6200ee"));
        dataSet.setDrawCircleHole(false);
        LineData lineData = new LineData(dataSet);

        line_Chart.setData(lineData);
        line_Chart.setDrawGridBackground(false);
        line_Chart.getAxisLeft().setDrawGridLines(false);
        line_Chart.getAxisRight().setDrawGridLines(false);

        line_Chart.setVisibility(View.VISIBLE);
        line_Chart.invalidate();
    }

    private void fetchTrendingKeyword(String keyword) {
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        String jsonURL = "http://androidnewsapp.us-east-1.elasticbeanstalk.com/trendingKeyword/"+keyword;
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, jsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            dataStatus = true;
                            trendingWordData = response.getJSONObject("default").getJSONArray("timelineData");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", "Error");
                    }
                }
        );
        requestQueue.add(objectRequest);
    }
}
